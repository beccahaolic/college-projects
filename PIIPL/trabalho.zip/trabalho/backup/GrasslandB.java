/* Grassland.java */

import java.util.ArrayList;
import java.util.Collections;

public class GrasslandB {

  public final static int EMPTY = 0;
  public final static int CARROT = 1;
  public final static int RABBIT = 2;
  
  private int height = 0;
  private int width = 0;
  private int starveTime = 5;
  int[][] meadow; //// contem 0, 1 e 2 para representar as posições de relva, cenouras e coelhos
  //private RABBIT[][] bunnies; //contem RABBIT nas mesmas posições onde meadow contem 2, o resto é null
  Object[][] test;
  
  public GrasslandB(int i, int j, int starveTime){ //construtor

    this.width = i;
    this.height = j;
    this.starveTime = starveTime;
    meadow = new int [width][height];
    //test = new Object[width][height];
  }
  
  public int width() {
    return this.width;
  }

  public int height() {
    return this.height;
  }

  public int starveTime() {
    return this.starveTime;
  }

  public void addCarrot(int x, int y) { //////////////-> modf try and catch

    try{

      if(this.meadow[x][y] == EMPTY){
        this.meadow[x][y] = CARROT;
        //this.test[x][y] = CARROT;
      }    //in other cases is not altered
      else if(this.meadow == null){
        throw new Exception("add carrot -> null array"); //use dif kind of exception
      }
      //else if(){}
    }
    catch(Exception A){
      System.out.println(A.getMessage());
    }
  }


  public void addRabbit(int x, int y) {

    try{
      if(this.meadow[x][y] == EMPTY){
        this.meadow[x][y] = RABBIT;
        
      }
      else if(this.meadow == null){
        throw new Exception("add rabbit -> null array"); // ig we gotta change this exception type
      }
    }
    catch(Exception W){
      System.out.println(W.getMessage());
    }

  }


  public int cellContents(int x, int y){ //* watch out the exceptions */

    try{
    if(this.meadow[x][y] == EMPTY){
      return EMPTY;
    }
    else if(this.meadow[x][y] == CARROT){
      return CARROT;
    }
    else if(this.meadow[x][y] >= 2){
      return RABBIT;
    }
    else{
      throw new Exception("cell contents: number != than empty, carrot or rabbit");
    }
  }
    catch (Exception E){
      System.out.println(E.getMessage());
      return -1;
    }
  }

  /*
   * esse método calcula as coordenadas adjecentes no ponto i, j
   * devolve num array list
   */

  public ArrayList<int[]> coor_adjacentes(int i, int j){ 

    ArrayList<int[]> coordinates = new ArrayList<int[]>();
    int aux_i = Math.floorMod(i - 1, width);
    int aux_j = Math.floorMod(j- 1, height);
    int aux_a = Math.floorMod(i + 1, width);
    int aux_b = Math.floorMod(j + 1, width);

    int topLeft[] = {aux_i, aux_j}; 
    int top[] = {i, aux_j};
    int topRight[] = {aux_a, aux_j};

    int midLeft[] = {aux_i, j};
    int midRight[] = {aux_a, j};

    int botLeft[] = {aux_i, aux_b};
    int bot[] = {i, aux_b};
    int botRight[] = {aux_a, aux_b};

    coordinates.add(topLeft);
    coordinates.add(top);
    coordinates.add(topRight);
    coordinates.add(midLeft);
    coordinates.add(midRight);
    coordinates.add(botLeft);
    coordinates.add(bot);
    coordinates.add(botRight);

    return coordinates;
  }

  public ArrayList<Integer> test(int i, int j){
    // coloca os elementos coelho, empty e carrot dos pontos adjacentes 

    ArrayList<int[]> coordenadas = coor_adjacentes(i, j);
    ArrayList<Integer> conteudo = new ArrayList<Integer>();

    for(int[] index: coordenadas){
      conteudo.add(meadow[index[0]][index[1]]);
    }

    return conteudo;
  }

  public int[] choose(int i, int j, int type){ // metodo que retorna 1 dos pontos adjacentes que contem "type" num array
  /*ex: para que o coelho coma a cenoura, a cell atual(coelho) i,j -> tem um ou mais pontos adjacentes que contem CARROT (type) */
    
  ArrayList<int[]> coordenadas = coor_adjacentes(i, j);
    ArrayList<Integer> conteudo = test(i, j);
    int index = conteudo.indexOf(type); //no caso, escolhe a 1ª cell em que aparece a cenoura
    //não deve ser aleatório?

    return coordenadas.get(index);
  }

  public GrasslandB timeStep() { // ainda não organizei as excepções aqui

    GrasslandB meowtwo = new GrasslandB(width, height, starveTime);

    int aux[] = new int[2];
try{
      for(int j = 0; j < this.height; j++){
        for(int i = 0; i < this.width; i++){

          ArrayList<Integer> coordinates = test(i, j);
          int auxx = Collections.frequency(coordinates, RABBIT);
          int auxx2 = Collections.frequency(coordinates, CARROT);


          // CASO 1 -> A CELL TEM UM COELHO //
          if(this.cellContents(i, j) == RABBIT){
  
            if( meadow[i][j] > 2 + starveTime){ // ou seja, se o coelho tem starvetime + 1 unidades de tempo sem alimento
              meowtwo.meadow[i][j] = 0; //coelho morre (vira prado)
            }
            else{
              if(auxx2 > 0){ //se algum vizinho é cenoura
                // se tiver + q uma cenoura, escolher uma delas aleatoriamente pra substituir???
                aux = choose(i, j, CARROT);
                meowtwo.meadow[i][j] = 2; 
                meowtwo.meadow[aux[0]][aux[1]] = 0; //substitui cenoura
              }
              else if(auxx2 <= 0){ //nenhum vizinho é cenoura 
                //bunny.AddLife(); // incrementa tempo de vida/ fome
                meowtwo.meadow[i][j] = meadow[i][j] + 1;
              }
              else{
                meowtwo.meadow[i][j] = 2;
              }

            }
          }
  
          // CASO 2 -> A CELL TEM UMA CENOURA //
          else if(this.cellContents(i, j) == CARROT){
  
            if(auxx == 1){ // tiver 1 coelho vizinho
              //é substituida
              aux = choose(i, j, RABBIT);
              meowtwo.meadow[aux[0]][aux[1]] = 2; //mudar pos do coelho pra 0
              meowtwo.meadow[i][j] = 0; //mudar pos da cenoura pra 0

            }
            else if(auxx >= 2){// tiver 2 ou mais coelhos vizinhos
              meowtwo.meadow[i][j] = 2;
            }
            else{
              meowtwo.meadow[i][j] = 1;
            }
            // se não existirem coelhos vizinhos, mantem-se -> por isso não escrevi else statement
          }
  
          // CASO 3 -> A CELL É RELVA/ ESTÁ VAZIA //
          else if(this.cellContents(i, j) == EMPTY){
  
            if(auxx2 >= 2 && auxx <= 1){// duas ou mais cenouras vizinhas; 1 ou menos coelhos vizinhos
              meowtwo.meadow[i][j] = 1; //nasce uma cenoura
            }
            else if(auxx2 >= 2 && auxx >= 2){ // duas cenouras ou mais cenoras vizinhas; 2 ou mais coelhos vizinhos
              meowtwo.meadow[i][j] = 2; //nasce um coelho
            }
            else{
              meowtwo.meadow[i][j] = 0;
            }
            // se não for nenhum dos casos, ela se mantem vazia -> não escrevi else statement
          }
          // SE NÃO FOR NENHUM DOS CASOS THROW EXCEPTION
          else{
            System.out.println("something is wrong");
            throw new Exception();/// fix this too
          }
  
        }
      }
    }
    catch(Exception f){
      System.out.println(f.getMessage());
    }

    //meowtwo.meadow = this.meadow; //since i altered only the current meadow, i reference the new meadow to the original one
    //System.arraycopy(this.meadow, 0, meowtwo.meadow, 0, );
    //meowtwo.meadow = this.meadow.clone();

    return meowtwo;
  }

}

