package com.iotproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iotproject.model.Device;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Long> {
    // Additional custom query methods can be defined here if needed
        // Verifica se já existe um dispositivo com o nome
        boolean existsByName(String name);
}