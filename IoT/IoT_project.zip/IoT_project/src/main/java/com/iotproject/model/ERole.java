package com.iotproject.model;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN;
}
